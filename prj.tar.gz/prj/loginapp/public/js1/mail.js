'use strict'

var app = angular.module('SnikeGame', []);

app.controller('myCtrl',function($scope) {

});

